#ifndef __VERSION_H__
#define __VERSION_H__
#define VERSION ""
#endif
