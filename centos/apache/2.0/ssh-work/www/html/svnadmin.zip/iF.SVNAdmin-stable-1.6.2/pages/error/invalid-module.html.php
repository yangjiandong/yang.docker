<?php GlobalHeader(); ?>

<h1>Invalid Module Requested!</h1>
<p>You tried to request a module which is currently not available.</p>

<?php GlobalFooter(); ?>