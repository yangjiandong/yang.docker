-- ----
-- Extra commands to run after the tables are created, loaded,
-- indexes built and extra's created.
-- ----

analyze table bmsql_warehouse;
analyze table bmsql_district;
analyze table bmsql_customer;
analyze table bmsql_history;
analyze table bmsql_oorder;
analyze table bmsql_new_order;
analyze table bmsql_order_line;
analyze table bmsql_stock;
analyze table bmsql_item;
analyze table bmsql_config;
