Loss functions
==============

.. automodule:: spotlight.losses
   :members:
   :undoc-members:
