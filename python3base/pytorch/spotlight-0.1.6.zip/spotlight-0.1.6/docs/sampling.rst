Sampling
========

.. automodule:: spotlight.sampling
   :members:
   :undoc-members:
