Sequence
========

.. automodule:: spotlight.sequence
   :members:

Submodules:

.. toctree::
   :maxdepth: 2

   Implicit feedback models <implicit>
   Sequence representations <representations>
