Implicit sequence models
========================

.. automodule:: spotlight.sequence.implicit
   :members:
   :undoc-members:
