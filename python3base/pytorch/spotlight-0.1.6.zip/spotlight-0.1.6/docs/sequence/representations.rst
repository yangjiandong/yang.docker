Sequence representations
========================

.. automodule:: spotlight.sequence.representations
   :members:
   :undoc-members:
