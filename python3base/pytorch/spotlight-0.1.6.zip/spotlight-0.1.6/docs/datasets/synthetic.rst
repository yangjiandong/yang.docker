Synthetic
=========


.. automodule:: spotlight.datasets.synthetic
   :members:
   :undoc-members:
