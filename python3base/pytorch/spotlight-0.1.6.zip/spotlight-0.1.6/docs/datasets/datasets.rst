Datasets
========

.. automodule:: spotlight.datasets
   :members:
   :undoc-members:

.. toctree::
   :maxdepth: 2

   Synthetic <synthetic>
   Movielens <movielens>
   Goodbooks <goodbooks>
