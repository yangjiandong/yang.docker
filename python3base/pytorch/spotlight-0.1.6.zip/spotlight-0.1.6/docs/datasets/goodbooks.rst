Goodbooks
=========


.. automodule:: spotlight.datasets.goodbooks
   :members:
   :undoc-members:
