Movielens
=========


.. automodule:: spotlight.datasets.movielens
   :members:
   :undoc-members:
