Implicit factorization models
=============================

.. automodule:: spotlight.factorization.implicit
   :members:
   :undoc-members:
