Latent representations
======================

.. automodule:: spotlight.factorization.representations
   :members:
   :undoc-members:
