Explicit factorization models
=============================

.. automodule:: spotlight.factorization.explicit
   :members:
   :undoc-members:
