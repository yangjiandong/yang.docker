Evaluation
==========

.. automodule:: spotlight.evaluation
   :members:
   :undoc-members:
