ADMIN_USER=admin ADMIN_PASSWORD=admin docker-compose up -d
