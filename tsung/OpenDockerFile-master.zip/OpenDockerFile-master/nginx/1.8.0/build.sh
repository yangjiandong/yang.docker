#opts="--no-cache"
docker build $opts -t library/centos7-nginx-1.8.0 .
