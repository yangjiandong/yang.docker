#!/bin/bash
/filedownload.sh
nginx $@
