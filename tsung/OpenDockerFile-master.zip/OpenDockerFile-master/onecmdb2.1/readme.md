手册文档链接：http://www.docin.com/p-577006628.html

镜像地址：index.shurenyun.com/onecmdb:2.1

docker run -p 8080:8080 index.shurenyun.com/onecmdb:2.1

admin/123

