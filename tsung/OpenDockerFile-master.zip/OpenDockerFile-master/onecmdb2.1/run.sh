#! /bin/bash
bin/onecmdb.sh start

while true
  do
 sleep 60
 done
