opts='--no-cache'
docker build $opts -t centos7/mesos-0.25.0-base .
