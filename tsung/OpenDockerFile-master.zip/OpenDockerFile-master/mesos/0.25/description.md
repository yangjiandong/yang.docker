### 数人云组件镜像地址
* mesos-master:  catalog.shurenyun.com/library/mesos-master-0.25:omega.v0.5
* mesos-slave :  catalog.shurenyun.com/library/mesos-slave-0.25:omega.v0.5
* marathon    :  catalog.shurenyun.com/library/marathon-0.13.1:omega.v0.5
