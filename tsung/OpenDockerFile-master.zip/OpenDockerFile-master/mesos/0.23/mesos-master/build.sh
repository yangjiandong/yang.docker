opts='--no-cache'
docker build $opts -t centos7/mesos-master-0.23 .
