opts='--no-cache'
docker build $opts -t centos7/mesos-slave-0.23 .
