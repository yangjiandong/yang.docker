opts='--no-cache'
docker build $opts -t centos7/marathon-0.9.1 .
