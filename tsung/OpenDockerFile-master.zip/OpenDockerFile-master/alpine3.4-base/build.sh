docker build -t library/alpine3.4-base .
