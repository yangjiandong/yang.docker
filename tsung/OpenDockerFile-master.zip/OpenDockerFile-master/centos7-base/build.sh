#opts="--no-cache"
docker build $opts -t demoregistry.dataman-inc.com/library/centos7-base .
