"""
Tsung log data parser.
"""
