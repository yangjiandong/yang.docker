==========
References
==========

* Tsung home page: http://tsung.erlang-projects.org/

* Tsung description (French) [#1]_

* Erlang web site http://www.erlang.org/

* Erlang programmation, Mickaël Rémond, Editions Eyrolles, 2003 [#2]_

* **Making reliable system in presence of software errors**, Doctoral Thesis,
  Joe Armstrong, Stockholm, 2003 [#3]_

* **Tutorial on How to write a Tsung plugin**, written by t ty,
  http://www.process-one.net/en/wiki/Writing_a_Tsung_plugin/


.. [#1] http://www.erlang-projects.org/Members/mremond/events/dossier_de_presentat/block_10766817551485/file
.. [#2] http://www.editions-eyrolles.com/php.accueil/Ouvrages/ouvrage.php3?ouv_ean13=9782212110791
.. [#3] http://www.sics.se/~joe/thesis/armstrong_thesis_2003.pdf
